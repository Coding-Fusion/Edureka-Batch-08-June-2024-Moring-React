function UserForm() {
  return (
    <>
      <h1>User Form</h1>
    </>
  );
}

export default UserForm;
