import { useState } from "react";
import Header from "./Header";
import TodoInput from "./TodoInput";
import TodosList from "./TodosList";

function Todo() {
  // handling input with useState
  let [inputText, setInputText] = useState("");
  let [todoList, setTodoList] = useState([]);

  let inputChange = (event) => {
    let _value = event.target.value;
    setInputText(_value);
  };
  let saveNewTodo = () => {
    let newTodo = {
      name: inputText,
      isCompleted: false,
    };
    // from start of array
    // let _todoList = [...todoList];// create a copy
    //_todoList.unshift(newTodo);// add data from start
    //setTodoList(_todoList);// update state

    setTodoList([newTodo, ...todoList]);
    alert("Todo added");
    setInputText(""); // resting input
  };

  let markAsComplete = (index) => {
    let _todoList = [...todoList];
    _todoList[index].isCompleted = true;
    setTodoList(_todoList);
  };

  let removeTodo = (index) => {
    // delete a array value with a location

    let isDelete = window.confirm("Are you sure delete ?");
    if (isDelete) {
      let _todoList = [...todoList];
      _todoList.splice(index, 1); // index, DeleteCount
      setTodoList(_todoList);
      alert("Delete Successfully");
    }
  };
  return (
    <>
      <section className="row justify-content-center">
        <section className="col-lg-6 col-10 col-md-8">
          <Header />
          <TodoInput
            inputText={inputText}
            inputChange={inputChange}
            saveNewTodo={saveNewTodo}
          />
          <TodosList
            todoList={todoList}
            markAsComplete={markAsComplete}
            removeTodo={removeTodo}
          />
        </section>
      </section>
    </>
  );
}

export default Todo;
