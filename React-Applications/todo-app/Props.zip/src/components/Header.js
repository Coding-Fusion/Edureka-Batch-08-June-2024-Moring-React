function Header() {
  return (
    <>
      <h1 className="text-center mt-3 text-primary">My Todos</h1>
    </>
  );
}

export default Header;
