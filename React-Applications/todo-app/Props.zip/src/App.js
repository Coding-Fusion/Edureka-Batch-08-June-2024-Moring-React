import Todo from "./components/Todo";

function App() {
  return (
    <>
      <section className="container-fluid">
        <Todo />
      </section>
    </>
  );
}

export default App;
